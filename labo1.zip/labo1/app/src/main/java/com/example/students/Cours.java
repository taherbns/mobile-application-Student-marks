package com.example.students;

public class Cours {

        private int numero;
        private String titre;
        private String session;
        private String professeur;
        private double note;


        public Cours(int numero, String titre, String session, String professeur, double note) {
            this.numero = numero;
            this.titre = titre;
            this.session = session;
            this.professeur = professeur;
            this.note = note;
        }

        public double getNote() {
            return note;
        }

        public void setNote(double note) {
            this.note = note;
        }

        public String getProfesseur() {
            return professeur;
        }

        public void setProfesseur(String professeur) {
            this.professeur = professeur;
        }

        public String getSession() {
            return session;
        }

        public void setSession(String session) {
            this.session = session;
        }

        public String getTitre() {
            return titre;
        }

        public void setTitre(String titre) {
            this.titre = titre;
        }

        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }


    }


