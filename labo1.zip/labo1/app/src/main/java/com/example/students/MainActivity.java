package com.example.students;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumero;
    private EditText editTextTitre;
    private EditText editTextSession;
    private EditText editTextProfesseur;
    private EditText editTextNote;
    private EditText editTextRecherche;
    private TextView textViewMoyenne;
    private TextView textViewTop3;
    private TextView textViewResultatRecherche;

    private ArrayList<Cours> listeCours = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextNumero = findViewById(R.id.editTextNumero);
        editTextTitre = findViewById(R.id.editTextTitre);
        editTextSession = findViewById(R.id.editTextSession);
        editTextProfesseur = findViewById(R.id.editTextProfesseur);
        editTextNote = findViewById(R.id.editTextNote);
        editTextRecherche = findViewById(R.id.editTextRecherche);
        textViewMoyenne = findViewById(R.id.textViewMoyenne);
        textViewTop3 = findViewById(R.id.textViewTop3);
        textViewResultatRecherche = findViewById(R.id.textViewResultatRecherche);

        Button boutonAjouter = findViewById(R.id.buttonAjouter);
        Button boutonRechercherSession = findViewById(R.id.buttonRechercherSession);
        Button boutonRechercherCours = findViewById(R.id.buttonRechercherCours);
        Button boutonRechercherProfesseur = findViewById(R.id.buttonRechercherProfesseur);
        Button boutonAfficherTop3 = findViewById(R.id.buttonAfficherTop3);

        boutonAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int numero = Integer.parseInt(editTextNumero.getText().toString());
                String titre = editTextTitre.getText().toString();
                String session = editTextSession.getText().toString();
                String professeur = editTextProfesseur.getText().toString();
                double note = Double.parseDouble(editTextNote.getText().toString());

                Cours cours = new Cours(numero, titre, session, professeur, note);

                listeCours.add(cours);

                double moyenne = calculerMoyenne(listeCours);
                textViewMoyenne.setText("Moyenne : " + moyenne);

                effacerChampsFormulaire();
            }
        });

        boutonRechercherSession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String session = editTextRecherche.getText().toString();
                rechercherCoursParSession(session);
            }
        });

        boutonRechercherCours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cours = editTextRecherche.getText().toString();
                rechercherCoursParCours(cours);
            }
        });

        boutonRechercherProfesseur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String professeur = editTextRecherche.getText().toString();
                rechercherCoursParProfesseur(professeur);
            }
        });

        boutonAfficherTop3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                afficherTop3Cours();
            }
        });
    }

    private double calculerMoyenne(ArrayList<Cours> listeCours) {
        if (listeCours.isEmpty()) {
            return 0.0;
        }

        double totalNotes = 0.0;
        int nombreCours = listeCours.size();

        for (Cours cours : listeCours) {
            totalNotes += cours.getNote();
        }

        return totalNotes / nombreCours;
    }

    private void rechercherCoursParSession(String session) {
        ArrayList<Cours> resultatRecherche = new ArrayList<>();

        for (Cours cours : listeCours) {
            if (cours.getSession().equals(session)) {
                resultatRecherche.add(cours);
            }
        }

        afficherResultatsRecherche(resultatRecherche);
    }

    private void rechercherCoursParCours(String cour) {
        ArrayList<Cours> resultatRecherche = new ArrayList<>();

        for (Cours cours : listeCours) {
            if (cours.getTitre().equals(cour)) {
                resultatRecherche.add(cours);
            }
        }

        afficherResultatsRecherche(resultatRecherche);
    }

    private void rechercherCoursParProfesseur(String professeur) {
        ArrayList<Cours> resultatRecherche = new ArrayList<>();

        for (Cours cours : listeCours) {
            if (cours.getProfesseur().equals(professeur)) {
                resultatRecherche.add(cours);
            }
        }

        afficherResultatsRecherche(resultatRecherche);
    }
    private void effacerChampsFormulaire() {
        editTextNumero.setText("");
        editTextTitre.setText("");
        editTextSession.setText("");
        editTextProfesseur.setText("");
        editTextNote.setText("");
    }

    private void afficherTop3Cours() {
        if (listeCours.isEmpty()) {
            textViewTop3.setText("Aucun cours enregistré.");
            return;
        }

        Collections.sort(listeCours, new Comparator<Cours>() {
            @Override
            public int compare(Cours cours1, Cours cours2) {
                return Double.compare(cours2.getNote(), cours1.getNote());
            }
        });
        StringBuilder top3Text = new StringBuilder("Top 3 des cours :\n");
        int count = Math.min(3, listeCours.size());
        for (int i = 0; i < count; i++) {
            Cours cours = listeCours.get(i);
            top3Text.append(cours.getTitre()).append(" - ").append(cours.getNote()).append("\n");
        }
        textViewTop3.setText(top3Text.toString());
    }

    private void afficherResultatsRecherche( ArrayList<Cours> resultatRecherche) {
        if (resultatRecherche.isEmpty()) {
            textViewResultatRecherche.setText("Aucun résultat trouvé.");
        } else {
            StringBuilder resultatText = new StringBuilder("Résultats de la recherche :\n");
            for (Cours cours : resultatRecherche) {
                resultatText.append(cours.getTitre()).append(" - ").append(cours.getNote()).append("\n");
            }
            textViewResultatRecherche.setText(resultatText.toString());
        }
    }
}
